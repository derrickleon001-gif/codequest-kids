---
name: Neo-Brutalist Playful Notebook
colors:
  surface: '#fff9ec'
  surface-dim: '#e0dac9'
  surface-bright: '#fff9ec'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#faf3e2'
  surface-container: '#f4eddd'
  surface-container-high: '#eee8d7'
  surface-container-highest: '#e9e2d2'
  on-surface: '#1e1c12'
  on-surface-variant: '#4d4632'
  inverse-surface: '#333025'
  inverse-on-surface: '#f7f0df'
  outline: '#7f7660'
  outline-variant: '#d1c6ab'
  surface-tint: '#725c00'
  primary: '#725c00'
  on-primary: '#ffffff'
  primary-container: '#ffd21f'
  on-primary-container: '#705b00'
  inverse-primary: '#edc200'
  secondary: '#a63557'
  on-secondary: '#ffffff'
  secondary-container: '#fd789a'
  on-secondary-container: '#740a32'
  tertiary: '#603ce3'
  on-tertiary: '#ffffff'
  tertiary-container: '#dad1ff'
  on-tertiary-container: '#5e3be1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffe080'
  primary-fixed-dim: '#edc200'
  on-primary-fixed: '#231b00'
  on-primary-fixed-variant: '#564500'
  secondary-fixed: '#ffd9df'
  secondary-fixed-dim: '#ffb1c1'
  on-secondary-fixed: '#3f0017'
  on-secondary-fixed-variant: '#861b40'
  tertiary-fixed: '#e6deff'
  tertiary-fixed-dim: '#cabeff'
  on-tertiary-fixed: '#1c0062'
  on-tertiary-fixed-variant: '#4716cb'
  background: '#fff9ec'
  on-background: '#1e1c12'
  surface-variant: '#e9e2d2'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 60px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Nunito Sans
    fontSize: 20px
    fontWeight: '800'
    lineHeight: 26px
  body-lg:
    fontFamily: Nunito Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 28px
  body-md:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-sm:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  code-block:
    fontFamily: Space Mono
    fontSize: 15px
    fontWeight: '700'
    lineHeight: 22px
  label-interactive:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '800'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-code-tag:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system lives at the vibrant intersection of a tactile school notebook, an arcade video game, and an institutional yet warm edtech platform. Tailored for young learners aged 6–12 alongside their guardians, it bridges two distinct visual registers: high-energy, tactile neo-brutalism for children ("Belajar coding sambil berpetualang!") and a composed, trustworthy aesthetic for the Parent Zone.

The design language mimics physical paper stationery brought to life: graph paper textures, folder-tab navigations, taped polaroid badges, and chunky, mechanical click surfaces. The interface rejects sterile, generic SaaS minimalism in favor of joyful physical metaphors—offset drop shadows, chunky ink lines, bold stickers, and animated brackets—while maintaining rigorous legibility, accessible hit states, and clear instructional hierarchy.

### Design Movements Integrated:
- **Playful Neo-Brutalism:** Pure #111111 ink borders (3px default), zero-blur directional offset drop shadows, energetic color blocks, and ultra-bold display type.
- **Stationery / Tactile Metaphors:** Paper cream canvas, ruled margins, folder tabs, tape strips, and stamp-like indicators.
- **Gentle EdTech (Parent Zone):** A calibrated sanctuary utilizing muted teals, softened borders, and lower sensory pressure for monitoring analytics, curriculum roadmaps, and screen time.

## Colors

The palette is engineered around high contrast, expressive gamification cues, and a paper-first tonal foundation. 

### Core Palette
- **Canvas Base (Paper Cream):** `#FFF8E7` provides the tactile foundation, soft on children's eyes compared to harsh pure white.
- **Ink & Structure:** `#111111` acts as the universal outline, label, and shadow color.
- **Primary (Sunny Yellow - `#FFD21F`):** Dedicated to primary action vectors (e.g., CTA `LANJUTKAN`), algorithmic logic, and the mascot anchor.
- **Secondary (Bubblegum Pink - `#FF7A9C`):** Used for interactive quizzes, hero callouts, and celebration highlights.
- **Tertiary (Grape Purple - `#7B5CFF`):** Powers computational challenges, code editor surfaces, and syntax containers (always paired with crisp white text).

### Utility & Gamification Accents
- **Logic Green:** `#C5F04D` — Used for Boolean tasks, test passes, and success toasts.
- **Progress Sky:** `#5CC8FF` — Denotes pathway mastery, XP meters, and active modules.
- **Loot Tangerine:** `#FF8A3D` — Badges, collectables, streak flames, and bonus stars.
- **Try-Again Orange:** `#FFB347` — Dedicated pedagogical mistake color. Harsh punitive reds are strictly prohibited; mistakes are framed as iterative debugging opportunities.

### Notebook Substrates
- **Grid Lines:** `#E9DFC6` at 1.5px lines spaced on 24px increments.
- **Margin Rule:** `#FF9AA8` vertical rule at 64px offset on notebook cards.

### Parent Zone (Calm Mode)
- **Parent Teal:** `#2F8F83` — Professional, trustworthy anchor color for parent-facing reporting.
- **Parent Cream:** `#F4F8E6` — Low-chroma container tone delivering visual relief.

## Typography

Typography delivers immediate legibility, playful punch, and technical scaffolding:
1. **Headline / Display (`Space Grotesk`):** Heavyweight, mechanical, and expressive with geometric punch. Uppercase rendering for milestone announcements, action banners, and high-impact hero headings.
2. **Body & Controls (`Nunito Sans`):** Rounded terminals, highly legible counters, and a friendly cadence suited for early readers. Weight 800 drives buttons, interactive labels, and scorecards; weight 600 governs narrative instructions and parent overviews.
3. **Code & Badges (`Space Mono`):** Fixed-width clarity for dynamic variable tokens, syntax expressions, blockly labels, and tab markers. Rendered with loose letter-spacing to support child finger-tracking and phonics-friendly scanning.

## Layout & Spacing

The layout is built on a responsive 12-column Bento Grid modular architecture framed by thick 3px black division strokes. The system relies on fixed 8px grid alignment multiples to ensure consistent chunkiness.

- **Desktop (1024px+):** 12-column grid, 2rem margins, 1.5rem gutters. Used for IDE views with dual panel layouts (Code Editor on left, Live Play Canvas on right).
- **Tablet (768px - 1023px):** 8-column layout, 1.5rem margins, 1.25rem gutters. Panels can collapse into vertical bento stacks with sticky execution docks.
- **Mobile (< 768px):** 4-column layout, 1rem margins, 1rem gutters. Interactive playground actions collapse into bottom sheets or tabbed carousel cards.

Touch targets across all layouts must adhere to a strict minimum interactive dimension of 56px × 56px to guarantee accessibility for small hands and developing motor skills.

## Elevation & Depth

This design system avoids blurry drop shadows, soft gaussian diffusions, and gradient blurs. Elevation is conveyed strictly through **mechanical hard-offset geometry** and tactile layer stacking:

- **Level 0 (Flat):** Graph paper canvas `#FFF8E7` with subtle `#E9DFC6` cross-hatch or dotted lines.
- **Level 1 (Stationary Cards):** 3px solid `#111111` stroke with an offset shadow of `5px 5px 0px #111111`.
- **Level 2 (Interactive Buttons / Floating Blocks):** 3px solid `#111111` stroke with an offset shadow of `4px 4px 0px #111111`.
- **Level 3 (Modals & Victory Overlays):** 4px solid `#111111` stroke with an offset shadow of `8px 8px 0px #111111`.
- **Active State (Mechanical Press):** Whenever an interactive element is pressed or focused, it translates down and right (`transform: translate(3px, 3px)` or `translate(4px, 4px)`) while the offset shadow collapses to `0px 0px 0px #111111` or `1px 1px 0px #111111`. This simulates the physical snap of an arcade button or mechanical keyboard switch.
- **Tape & Sticker Overlays:** Badges and quest milestones use a pseudo-random rotation (`transform: rotate(-1.5deg)` to `rotate(2deg)`) with a translucent masking tape strip across the top edge (`rgba(255, 255, 255, 0.6)` with ripped borders).

## Shapes

The design uses balanced, rounded brutalist geometry (`roundedness: 2` = 0.5rem base, 1rem for `rounded-lg`, 1.5rem for `rounded-xl`). Pure sharp rectangles are avoided to keep the environment friendly and child-safe, while pill-shapes are reserved specifically for tags and tactile pills.

### Signature Motifs:
- **Folder Tabs:** Rectangular containers with an asymmetrical top-left or top-right tab protrusion (`border-radius: 12px 12px 0 0`) framed in 3px solid ink strokes.
- **Curly-Brace Cutouts:** Accent cards and mascot visual anchors incorporate `{ }` motifs along the edges or within corner borders.
- **Polaroid Frames:** Media and badge containers feature a wide bottom white margin mimicking instant camera prints, held with a slight skew.

## Components

### Buttons
- **Primary Action (e.g., 'LANJUTKAN'):** Minimum height of 56px. Filled with Sunny Yellow `#FFD21F`. 3px solid `#111111` outline, `border-radius: 16px`, hard shadow `4px 4px 0px #111111`. Text in Nunito Sans 800, uppercase, with a rightward arrow or curly bracket `{ > }`. On hover, translate to `2px 2px 0px`; on active/click, translate to `4px 4px 0px` with shadow flattening.
- **Secondary (Kuis / Play):** Same geometry with Bubblegum Pink `#FF7A9C` or Lime Green `#C5F04D`.
- **Ghost Button:** Canvas-backed with thick 3px black stroke, white interior, and dark text.

### Interactive Chips & Code Pills
- **Syntax Blocks:** Grape Purple `#7B5CFF` fill with crisp white Space Mono text. `border: 2.5px solid #111111`, `border-radius: 8px`, `padding: 4px 12px`.
- **Attribute / Variable Pills:** Sky Blue `#5CC8FF` or Tangerine `#FF8A3D` pills indicating XP, levels, or data values (`{score: 100}`).

### Bento Cards & Folder Tabs
- Cards sit on white or pastel surfaces with a mandatory 3px solid `#111111` border and `5px 5px 0px #111111` hard shadow.
- **Folder Tab Card:** Top header contains a simulated file tab labeled with `Space Mono` uppercase category flags (e.g., `MODUL 01 // LOOPING`).

### Form Inputs & Text Fields
- Large-scale input bars (minimum 52px height). Background in `#FFFFFF`, border `3px solid #111111`, `border-radius: 12px`, with an internal inset shadow or subtle line pattern. Focused states swap the border stroke to Grape Purple `#7B5CFF` with an offset shadow of `3px 3px 0px #111111`.

### Checkboxes & Radio Controls
- **Checkbox:** Chunky 28px × 28px square with 3px border and 3px rounded corners. Unchecked: pure white with offset shadow `2px 2px 0px #111111`. Checked: Lime Green `#C5F04D` with a bold black checkmark `✓` drawn with a 4px stroke.
- **Radio Buttons:** 28px round pucks with a thick black inner circle when active.

### Progress Bars (XP & Mastery)
- Outlined progress track with 3px solid `#111111` and an inner fill of Sky Blue `#5CC8FF` or Lime Green `#C5F04D`. The bar contains diagonal comic-book hatch lines (`repeating-linear-gradient`) and a trailing star or mascot head indicator.

### Feedback Banners
- **Success:** Lime Green `#C5F04D` container, mascot celebration icon, copy: `"Hebat! Logikamu tepat!"`.
- **Encouragement / Retry:** Try-Again Orange `#FFB347` container, mascot head scratch icon, copy: `"Belum pas, ayo debug bareng!"`. Red alert boxes are never rendered to learners.

### Parent Zone Specialization
- Embedded inside the dashboard via a switch toggled behind a simple math gate. Features Parent Teal `#2F8F83` top bar, muted borders (1.5px solid `#2F8F83`), softly rounded statistics cards without brutalist rotations, and smooth linear charts tracking learning speed and concept retention.